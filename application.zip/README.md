# Workloads_Module4

Terraform code to deploy working resources within an established landing zone on AWS.